ESX = exports["es_extended"]:getSharedObject()


function openExtrasMenu(vehicle)
    local playerData = ESX.GetPlayerData()


    if playerData.job.name ~= 'police' then
        ESX.ShowNotification("You do not have permission to use this feature.")
        return
    end

    local options = {}

    for extraID = 0, 20 do
        if DoesExtraExist(vehicle, extraID) then
            local isExtraOn = IsVehicleExtraTurnedOn(vehicle, extraID)
            local label = 'Extra ' .. extraID .. (isExtraOn and ' (Enabled)' or ' (Disabled)')

            table.insert(options, {
                title = label,
                description = 'Toggle Extra ' .. extraID,
                event = 'volt_extras:toggleExtra', 
                args = {
                    vehicle = vehicle,
                    extraID = extraID
                }
            })
        end
    end


    if #options == 0 then
        ESX.ShowNotification("This vehicle has no extras to toggle.")
        return
    end


    exports.ox_lib:registerContext({
        id = 'toggle_extras_menu',
        title = 'Toggle Vehicle Extras',
        options = options
    })

    exports.ox_lib:showContext('toggle_extras_menu')
end


RegisterNetEvent('volt_extras:toggleExtra', function(data)
    local vehicle = data.vehicle
    local extraID = data.extraID

    toggleExtra(vehicle, extraID)
end)


function toggleExtra(vehicle, extraID)
    if DoesExtraExist(vehicle, extraID) then
        local isExtraOn = IsVehicleExtraTurnedOn(vehicle, extraID)

        if isExtraOn then
            SetVehicleExtra(vehicle, extraID, 1) -- Disable the extra
            ESX.ShowNotification("Extra " .. extraID .. " disabled.")
        else
            SetVehicleExtra(vehicle, extraID, 0) -- Enable the extra
            ESX.ShowNotification("Extra " .. extraID .. " enabled.")
        end
    else
        ESX.ShowNotification("Extra " .. extraID .. " does not exist on this vehicle.")
    end
end


Citizen.CreateThread(function()
    while true do
        Citizen.Wait(0)

        if IsControlJustReleased(1, 57) then -- F10 key
            local playerPed = GetPlayerPed(-1)
            local vehicle = GetVehiclePedIsIn(playerPed, false)

            if vehicle ~= 0 and GetPedInVehicleSeat(vehicle, -1) == playerPed then
                openExtrasMenu(vehicle)
            else
                ESX.ShowNotification("You must be in a vehicle to use this feature.")
            end
        end
    end
end)

print("VoltLabs Emergency Vehicles Extras Menu! Press F10 to use!")