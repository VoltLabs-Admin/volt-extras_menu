fx_version 'cerulean'
game 'gta5'
lua54 'yes'
author 'Nevairi'
description 'Vehicle Extras Toggle Script for ESX with ox_lib Menu'
version '1.0.0'

client_scripts {
    '@es_extended/imports.lua',  
    '@ox_lib/init.lua',         
    'volt_extras.lua'            
}


dependencies {
    'es_extended',
    'ox_lib'
}
