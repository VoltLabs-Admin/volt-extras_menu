Config = {}
Config.MenuKey = 57  -- F10 key
Config.NotificationStyle = 'esx' -- You can change this to 'ox' if you use ox_notify
